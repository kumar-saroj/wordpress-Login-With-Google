<?php
/**
 * Plugin Name: Login With Google
 * Description: This plugin will add a Login with Google Button in loginform
 * Plugin URI: https://github.com/kumar-saroj
 * Author: Saroj Kumar
 * Version: 0.0.1
**/

//* Don't access this file directly
defined( 'ABSPATH' ) or die();

/**
 * Google App Configuration
 **/
// call sdk library
require_once 'google-api/vendor/autoload.php';

$gClient = new Google_Client();
$gClient->setClientId(get_option('client_id'));
$gClient->setClientSecret(get_option('client_secret'));
$gClient->setApplicationName(get_option('application_name'));
$gClient->setRedirectUri(get_option('returnurl'));
$gClient->addScope("https://www.googleapis.com/auth/plus.login https://www.googleapis.com/auth/userinfo.email");

// login URL
$login_url = $gClient->createAuthUrl();

function my_plugin_action_links( $links ) {

	$links = array_merge( array(
		'<a href="' . esc_url( admin_url( '/options-general.php?page=login-setting' ) ) . '">' . __( 'Settings', 'textdomain' ) . '</a>'
	), $links );

	return $links;

}
add_action( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'my_plugin_action_links' );




function codechief_custom_plugin_page()
{
    add_options_page('Login Setting', 'Login Setting', 'manage_options', 'login-setting', 'login_setting_page');
    add_action( 'admin_init', 'register_my_login_settings' );
}
function register_my_login_settings() {
	//register our settings
	register_setting( 'my-login-settings-group', 'client_id' );
	register_setting( 'my-login-settings-group', 'client_secret' );
	register_setting( 'my-login-settings-group', 'application_name' );
    register_setting( 'my-login-settings-group', 'returnurl' );
}

add_action('admin_menu', 'codechief_custom_plugin_page');

function login_setting_page()
{
   ?>
    <form method="post" action="options.php">
    <?php settings_fields( 'my-login-settings-group' ); ?>
    <?php do_settings_sections( 'my-login-settings-group' ); ?>
    <table class="form-table">
        <tr valign="top">
        <th scope="row">Client ID</th>
        <td><input type="text" name="client_id" value="<?php echo esc_attr( get_option('client_id') ); ?>" style="width:60%" /></td>
        </tr>
         
        <tr valign="top">
        <th scope="row">Client Secret</th>
        <td><input type="text" name="client_secret" value="<?php echo esc_attr( get_option('client_secret') ); ?>" style="width:60%"  /></td>
        </tr>
        
        <tr valign="top">
        <th scope="row">Application Name</th>
        <td><input type="text" name="application_name" value="<?php echo esc_attr( get_option('application_name') ); ?>" style="width:60%"  /></td>
        </tr>
        <tr valign="top">
        <th scope="row">Return URL</th>
        <td><input type="text" name="returnurl" value="<?php echo esc_attr( get_option('returnurl') ); ?>" style="width:60%"  /></td>
        </tr>
        <tr>
            <td colspan="2"><p>You can use <code>[google-login]</code> any page or post;</p></td>
        </tr>
    </table>
    
    <?php submit_button(); ?>

</form>
   <?php
}

add_action( 'login_form', 'wpse8170_login_form_register' );
function wpse8170_login_form_register() {
    global $login_url;
    if(!get_option('users_can_register')){
        ?>
           <div>Allow to register!</div>
        <?php
    }
    else{
        ?>
         <a style="display: block; margin-bottom: 10px;background: #fff;color: #333;border: 1px solid #ccc;padding: 10px;text-transform: uppercase;text-decoration: none;text-align: center;font-size: 17px; border-radius:5px" href="<?php echo $login_url; ?>"><img style="width:8%" src="<?php echo plugins_url( 'images/glogo.png' , __FILE__ ); ?>"><span style="display: inline-block;padding-left: 6px; vertical-align: super;">Login with google</span></a>
            
        <?php
    }
}
// generate button shortcode
add_shortcode('google-login', 'sd_login_with_google');
function sd_login_with_google(){
    global $login_url;
    $btnContent = '
        <style>
            .googleBtn{
                display: table;
                margin: 0 auto;
                background: #4285F4;
                padding: 15px;
                border-radius: 3px;
                color: #fff;
            }
        </style>
    ';
    if(!is_user_logged_in()){
            // checking to see if the registration is opend
            if(!get_option('users_can_register')){
                return($btnContent . 'Registration is closed!');
            }else{
                return $btnContent . '<a class="googleBtn" href="'.$login_url.'">Login With Google</a>';
            }

    }else{
        $current_user = wp_get_current_user();
        return $btnContent . '<div class="googleBtn">Hi, ' . $current_user->first_name . '! - <a href="'.wp_logout_url( home_url() ).'">Log Out</a></div>';
    }
}

// add ajax action
add_action('wp_ajax_sd_login_google', 'sd_login_google');
function sd_login_google(){
    // echo "fffff";
    global $gClient;
    // checking for google code
    if (isset($_GET['code'])) {
        $token = $gClient->fetchAccessTokenWithAuthCode($_GET['code']);
        if(!isset($token["error"])){
            // get data from google
            $oAuth = new Google_Service_Oauth2($gClient);
            $userData = $oAuth->userinfo_v2_me->get();
        }

        // check if user email already registered
        if(!email_exists($userData['email'])){
            // generate password
            $bytes = openssl_random_pseudo_bytes(2);
            $password = md5(bin2hex($bytes));
            $user_login = $userData['id'];


            $new_user_id = wp_insert_user(array(
                'user_login'		=> $user_login,
                'user_pass'	 		=> $password,
                'user_email'		=> $userData['email'],
                'first_name'		=> $userData['givenName'],
                'user_nicename' => $userData['givenName'],
                'display_name' => $userData['givenName'],
                'last_name'			=> $userData['familyName'],
                'user_registered'	=> date('Y-m-d H:i:s'),
                'role'				=> 'subscriber'
                )
            );
            if($new_user_id) {
                // send an email to the admin
                wp_new_user_notification($new_user_id);
                
                // log the new user in
                do_action('wp_login', $user_login, $userData['email']);
                wp_set_current_user($new_user_id);
                wp_set_auth_cookie($new_user_id, true);
                
                // send the newly created user to the home page after login
                wp_redirect(home_url()); exit;
            }
        }else{
            //if user already registered than we are just loggin in the user
            $user = get_user_by( 'email', $userData['email'] );
            do_action('wp_login', $user->user_login, $user->user_email);
            wp_set_current_user($user->ID);
            wp_set_auth_cookie($user->ID, true);
            wp_redirect(home_url()); exit;
        }


        //var_dump($userData);
    }else{
        wp_redirect(home_url());
        exit();
    }
}

// ALLOW LOGGED OUT users to access admin-ajax.php action
function add_google_ajax_actions(){
    add_action('wp_ajax_nopriv_sd_login_google', 'sd_login_google');
}
add_action('admin_init', 'add_google_ajax_actions');